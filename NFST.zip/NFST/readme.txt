Font Scene Text (NFST) dataset is made up of 100 text images with novel or unusual font styles collected from IIIT5k , IC13, IC15, SVTP and COCO-T datasets.
This dataset is proposed for the community to better measure the font-robustness of scene text recognition models.
If you use this dataset or find our work is helpful, please consider citing our work:
Yizhi Wang and Zhouhui Lian. Exploring Font-independent Features for Scene Text Recognition. ACM Multimedia. 2020.